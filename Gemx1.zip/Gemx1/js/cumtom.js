$(document).ready(function () {
	
	 $('body').scrollspy({target: "#nav-part"}) 
	
	
    //animation scroll js for navbar
    var html_body = $('html, body');
    $('nav a').on('click', function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                html_body.animate({
                    scrollTop: target.offset().top  -0
                }, 1500);
                return false;
            }
        }
    });
	
    //sticky top js
	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			$(".navbar").addClass("navbg");
		} else {
			$(".navbar").removeClass("navbg");
		}
	});
	
 
	
    // isotope
    $('.filter_part').isotope({
      // options
      itemSelector: '.items'
    });

    var $gallery = $('.filter_part').isotope({
      // options
    });

    // filter items on button click
    $('.common_content').on( 'click', 'span', function() {
        var filterValue = $(this).attr('data-filter');
        $gallery.isotope({ filter: filterValue });
    });

    $('.common_content').on( 'click', 'span', function() {
        $(this).addClass('active').siblings().removeClass('active');
    });	
	$('.slider-main').slick({
		  slidesToShow: 1,
		  slidesToScroll: 1,
		  autoplay: true,
		  autoplaySpeed: 2000,
		  dots: true,
		  arrows: false,
		  infinite: true,
		  speed: 1000,
		  fade: true,
		  cssEase: 'linear',
		
		responsive: [
			{
				breakpoint: 1200,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
},

			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
},

			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
}

]

	});
		
	//slider part js start
	$('.slider_part').slick({
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 2000,
		arrows: false,
		dots: true,

		responsive: [
			{
				breakpoint: 1200,
				settings: {
					slidesToShow: 4,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
},

			{
				breakpoint: 576,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
},

			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
}

]

	});
	
	//slider part js start
	$('.slider_start').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 2000,
		arrows: false,
		dots: true,

		responsive: [
			{
				breakpoint: 1200,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
},
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					infinite: true,
					dots: true
				}
},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
},

			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
},

			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
}

]

	});
	
	// Regular map
        function regular_map() {
            var var_location = new google.maps.LatLng(23.756191, 90.351890);

            var var_mapoptions = {
                center: var_location,
                zoom: 14
            };

            var var_map = new google.maps.Map(document.getElementById("map-container"),
                var_mapoptions);

            var var_marker = new google.maps.Marker({
                position: var_location,
                map: var_map,
                title: "New York"
            });
        }

        // Initialize maps
        google.maps.event.addDomListener(window, 'load', regular_map);
		
	
    // Closes responsive menu when a scroll link is clicked
    $('.nav-link').on('click', function () {
        $('.navbar-collapse').collapse('hide');
    });
	
	//
    $('.counter').countUp({
        delay: 10,
        time: 1500
    });
	
	
	//back to top js start
	$(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.btn_back_top').fadeIn();
        } else {
            $('.btn_back_top').fadeOut();
        }
    });

    $('.btn_back_top').click(function () {
        $('html, body').animate({
            scrollTop: 0
        }, 800);
        return false;
    });
   
	// Preloader js    
	$(window).on('load', function () {
		$('.preloader').delay(1500).fadeOut(500);
	});

});